package com.example.loginscreen;

import static android.content.ContentValues.TAG;

import android.util.Log;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class FirestoreVeriKaynagi {
    private FirebaseFirestore veritabani = FirebaseFirestore.getInstance();

    public void kullaniciBilgileriniGetir(Consumer<List<Kullanici>> callback) {
        veritabani.collection("Users").get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    List<Kullanici> kullaniciList = new ArrayList<>();
                    for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                        Kullanici kullanici = documentSnapshot.toObject(Kullanici.class);
                        kullaniciList.add(kullanici);
                    }
                    callback.accept(kullaniciList);
                })
                .addOnFailureListener(e -> Log.e(TAG, "Verileri alma hatası", e));
    }
}

class Kullanici {
    public String userName;
    public String userEmail;
    public String ulke;
    public String sehir;
    public String firma;

    public Kullanici() {}

    public Kullanici(String ad, String soyad, int yas) {
        this.userName = userName;
        this.userEmail = userEmail;
    }
}

