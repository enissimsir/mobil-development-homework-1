package com.example.loginscreen;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
import android.view.View;

public class CustomerMainPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_main_page);
        Button makeApButton = findViewById(R.id.profil);
        makeApButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CustomerMainPage.this, Profil.class);
                startActivity(intent);
            }
        });

        Button myApsButton = findViewById(R.id.my_appointments);
        myApsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CustomerMainPage.this, Search.class);
                startActivity(intent);
            }
        });
    }


}