package com.example.loginscreen;

import android.Manifest;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class Profil extends AppCompatActivity {
    public static final int IZIN_KODU = 0;
    public static final int IZIN_ALINDI_KODU = 1;


    private FirebaseUser mUser;
    private FirebaseFirestore db;
    private String userId;
    private DocumentReference userRef;
    private Uri mUri;
    private Intent galleryIntent;
    private Bitmap gelenResim;
    private ImageDecoder.Source imgSource;
    private ByteArrayOutputStream outputStream;
    private byte[] imgByte;
    private StorageReference mStorageRef, yeniRef, imageRef, ppRef;
    private String kayitYeri, indirmeLinki, imgUrl;
    private HashMap<String, Object> mData;

    ImageView pp;

    ActivityResultLauncher activityResultLauncher;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);
        Button kaydetButton = (Button) findViewById(R.id.buttonKaydet);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        EditText ulkeEditText = findViewById(R.id.editTextUlke);
        EditText sehirEditText = findViewById(R.id.editTextSehir);
        EditText firmaEditText = findViewById(R.id.editTextFirma);
        EditText telNoEditText = findViewById(R.id.editTextPhone);
        Button fotografDegis = (Button) findViewById(R.id.buttonFotografDegis);
        pp = (ImageView) findViewById(R.id.imageView);

        resmiGetir();

        kaydetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedEducationType = radioGroup.getCheckedRadioButtonId();
                if (selectedEducationType != -1) {
                    RadioButton radioButton = findViewById(selectedEducationType);
                    String educationTypeText = radioButton.getText().toString();
                    veriGuncelle("educationType", educationTypeText, new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            // educationType güncellendi
                            String ulkeText = ulkeEditText.getText().toString();
                            veriGuncelle("Ulke", ulkeText, new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    // Ulke güncellendi
                                    String sehirText = sehirEditText.getText().toString();
                                    veriGuncelle("Sehir", sehirText, new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            // Sehir güncellendi
                                            String firmaText = firmaEditText.getText().toString();
                                            veriGuncelle("Firma", firmaText, new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void aVoid) {
                                                    // Firma güncellendi
                                                    String telNo = telNoEditText.getText().toString();
                                                    veriGuncelle("telNo", telNo, new OnSuccessListener<Void>() {
                                                        @Override
                                                        public void onSuccess(Void aVoid) {
                                                            // Tüm veriler güncellendi
                                                            Toast.makeText(Profil.this, "Tüm veriler başarıyla güncellendi", Toast.LENGTH_SHORT).show();
                                                        }
                                                    });
                                                }
                                            });
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            }
        });
  /*      activityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if(result.getResultCode() == RESULT_OK && result.getData() != null){
                    Bundle bundle = result.getData().getExtras();
                    Bitmap bitmap = (Bitmap) bundle.get("data");
                    pp.setImageBitmap(bitmap);
                }
            }
        }); */

        fotografDegis.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("QueryPermissionsNeeded")
            @Override
            public void onClick(View view) {
                askGalleryPermission();
            }
        });
    }
    private void resmiGetir(){
        System.out.println("control 1");
        db = FirebaseFirestore.getInstance();
        mUser = Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser());
        userId = Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid();

        // Firestore'dan mevcut kullanıcı bilgilerini alın
        userRef = db.collection("Users").document(userId);
        mStorageRef = FirebaseStorage.getInstance().getReference();
        userRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                imgUrl = documentSnapshot.getString("userPP");
                if(imgUrl != null){
                    imageRef = mStorageRef.child("Users/" + mUser.getEmail() + "/profil.png");
                    imageRef.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
                        @Override
                        public void onComplete(@NonNull Task<Uri> task) {
                            if (task.isSuccessful()) {
                                Uri uri = task.getResult();
                                Picasso.get().load(uri).into(pp);
                            } else {
                                pp.setImageResource(R.drawable.defaultpp);
                                Toast.makeText(Profil.this, "Download URL couldn't be retrieved: " + Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }else{
                    pp.setImageResource(R.drawable.defaultpp);
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                pp.setImageResource(R.drawable.defaultpp);
            }
        });
        System.out.println("control 2");
    }

    private void askGalleryPermission(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, IZIN_KODU);
        }else{
            galeriyeGit();
        }
    }

    private void askCameraPermissions() {
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.CAMERA}, IZIN_KODU);
        }else {
            //openCamera();
        }

    }

    private final ActivityResultLauncher<Intent> galleryLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        mUri = result.getData().getData();
                        try {
                            if(Build.VERSION.SDK_INT >= 28){
                                imgSource = ImageDecoder.createSource(getContentResolver(), mUri);
                                gelenResim = ImageDecoder.decodeBitmap(imgSource);
                            }else{
                                gelenResim = MediaStore.Images.Media.getBitmap(getContentResolver(), mUri);
                            }
                            outputStream = new ByteArrayOutputStream();
                            gelenResim.compress(Bitmap.CompressFormat.PNG, 75, outputStream);
                            imgByte = outputStream.toByteArray();

                            kayitYeri = "Users/" + mUser.getEmail() + "/profil.png";
                            imageRef = mStorageRef.child(kayitYeri);
                            imageRef.putBytes(imgByte)
                                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                        @Override
                                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                            yeniRef = FirebaseStorage.getInstance().getReference(kayitYeri);
                                            yeniRef.getDownloadUrl()
                                                    .addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                        @Override
                                                        public void onSuccess(Uri uri) {
                                                            indirmeLinki = uri.toString();
                                                            mData = new HashMap<>();
                                                            mData.put("userPP", indirmeLinki);

                                                            db.collection("Users").document(mUser.getUid())
                                                                    .update(mData)
                                                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                        @Override
                                                                        public void onComplete(@NonNull Task<Void> task) {
                                                                            if(task.isSuccessful()){
                                                                                Toast.makeText(Profil.this,"PP guncellendi", Toast.LENGTH_SHORT).show();
                                                                                resmiGetir();
                                                                            }else
                                                                                Toast.makeText(Profil.this,task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                                                                        }
                                                                    });
                                                        }
                                                    }).addOnFailureListener(new OnFailureListener() {
                                                        @Override
                                                        public void onFailure(@NonNull Exception e) {
                                                            Toast.makeText(Profil.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                                                        }
                                                    });
                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Toast.makeText(Profil.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                                        }
                                    });
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
            });


    private void galeriyeGit(){
 //       galleryLauncher.launch("image/*");
        galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        galleryLauncher.launch(galleryIntent);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == IZIN_KODU){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                //camerada calismaz
                galeriyeGit();
            }else {
                Toast.makeText(Profil.this, "Permission is Required.", Toast.LENGTH_SHORT).show();
            }
        }
        super.onRequestPermissionsResult(requestCode,permissions, grantResults);
    }
/*
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == IZIN_ALINDI_KODU){
            if (resultCode == RESULT_OK && data!=null && data.getData()!=null){
                mUri = data.getData();
                try {
                    if(Build.VERSION.SDK_INT >= 28){
                        imgSource = ImageDecoder.createSource(this.getContentResolver(), mUri);
                        gelenResim = ImageDecoder.decodeBitmap(imgSource);
                    }else{
                        gelenResim = MediaStore.Images.Media.getBitmap(this.getContentResolver(), mUri);
                    }
                    outputStream = new ByteArrayOutputStream();
                    gelenResim.compress(Bitmap.CompressFormat.PNG, 75, outputStream);
                    imgByte = outputStream.toByteArray();

                    kayitYeri = "Users/" + mUser.getEmail() + "/profil.png";
                    StorageReference imageRef = mStorageRef.child(kayitYeri);
                    UploadTask uploadTask = imageRef.putFile(mUri);
                    imageRef.putBytes(imgByte)
                            .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                    yeniRef = FirebaseStorage.getInstance().getReference(kayitYeri);
                                    yeniRef.getDownloadUrl()
                                            .addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                @Override
                                                public void onSuccess(Uri uri) {
                                                    indirmeLinki = uri.toString();
                                                    mData = new HashMap<>();
                                                    mData.put("userPP", indirmeLinki);

                                                    db.collection("Users").document(mUser.getUid())
                                                            .update(mData)
                                                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                @Override
                                                                public void onComplete(@NonNull Task<Void> task) {
                                                                    if(task.isSuccessful()){
                                                                        Toast.makeText(Profil.this,"PP guncellendi", Toast.LENGTH_SHORT).show();
                                                                    }else
                                                                        Toast.makeText(Profil.this,task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                                                                }
                                                            });
                                                }
                                            }).addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Toast.makeText(Profil.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                                                }
                                            });
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(Profil.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                                }
                            });
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    } */

    private void veriGuncelle(String key, String val, OnSuccessListener<Void> listener){
        userRef.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                if(documentSnapshot.exists()){
                    Map<String, Object> userData = documentSnapshot.getData();

                    Map<String, Object> updatedData = new HashMap<>();
                    updatedData.put(key, val);
                    // Mevcut verileri güncelleyin
                    assert userData != null;
                    userData.putAll(updatedData);

                    // Firestore'a yükleyin
                    userRef.set(userData).addOnSuccessListener(listener).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(Profil.this, "Güncelleme başarısız", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }
}