package com.example.loginscreen;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class FirestoreRecyclerViewAdapter extends RecyclerView.Adapter<FirestoreRecyclerViewAdapter.ViewHolder> {
    private List<Kullanici> kullaniciList;

    public FirestoreRecyclerViewAdapter(List<Kullanici> kullaniciList) {
        this.kullaniciList = kullaniciList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.graduates_person, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Kullanici kullanici = kullaniciList.get(position);
        holder.adTextView.setText(kullanici.userName);
        holder.emailTextView.setText(kullanici.userEmail);
    }

    @Override
    public int getItemCount() {
        return kullaniciList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView adTextView;
        public TextView emailTextView;
        public TextView ulkeTextView;
        public TextView sehirTextView;
        public TextView firmaTextView;

        public ViewHolder(View view) {
            super(view);
            adTextView = view.findViewById(R.id.graduates_isim);
            emailTextView = view.findViewById(R.id.graduates_email);
            ulkeTextView = view.findViewById(R.id.ulkeTxt);
            sehirTextView = view.findViewById(R.id.sehirTxt);
            firmaTextView = view.findViewById(R.id.firmaTxt);
        }
    }
}