package com.example.loginscreen;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;

public class RegisterPage extends AppCompatActivity {
    private String txtEmail, txtuserName, txtPassword, txtRepassword;
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private HashMap<String, Object> mData;
    private FirebaseFirestore mFireStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_page);

        EditText userName = (EditText) findViewById(R.id.editTextUlke);
        EditText email = (EditText) findViewById(R.id.email);
        EditText password = (EditText) findViewById(R.id.password);
        EditText repassword = (EditText) findViewById(R.id.repassword);
        Button registerButton = (Button) findViewById(R.id.registerButton);

        mAuth = FirebaseAuth.getInstance();
        mFireStore = FirebaseFirestore.getInstance();

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usernameText = userName.getText().toString();
                String emailText = email.getText().toString();
                String passwordText = password.getText().toString();
                String repasswordText = repassword.getText().toString();

                if(!TextUtils.isEmpty(usernameText) && !TextUtils.isEmpty(emailText)
                && !TextUtils.isEmpty(passwordText) && !TextUtils.isEmpty(repasswordText)){
                    if(passwordText.equals(repasswordText)) {
                        mAuth.createUserWithEmailAndPassword(emailText, passwordText)
                                .addOnCompleteListener(RegisterPage.this, new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                        if (task.isSuccessful()) {
                                            mUser = mAuth.getCurrentUser();

                                            mData = new HashMap<>();
                                            mData.put("userName", usernameText);
                                            mData.put("userEmail", emailText);
                                            mData.put("userPassword", passwordText);
                                            mData.put("userID", mUser.getUid());

                                            mFireStore.collection("Users").document(mUser.getUid())
                                                .set(mData)
                                                .addOnCompleteListener(RegisterPage.this, new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if(task.isSuccessful()){
                                                            Toast.makeText(RegisterPage.this, "Kayit Basarili", Toast.LENGTH_SHORT).show();
                                                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                                            startActivity(intent);
                                                        }
                                                        else{
                                                            Toast.makeText(RegisterPage.this,task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                                        }
                                                    }
                                                });
                                        } else {
                                            Toast.makeText(RegisterPage.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                    }
                    else{
                        Toast.makeText(getApplicationContext(),"Sifreler uyusmali",Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(getApplicationContext(),"Bos alan kalmamali",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public void register(View view){

    }
}