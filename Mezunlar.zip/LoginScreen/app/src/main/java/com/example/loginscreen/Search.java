package com.example.loginscreen;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class Search extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private FirestoreVeriKaynagi firestoreVeriKaynagi;
    private FirestoreRecyclerViewAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        mRecyclerView = (RecyclerView) findViewById(R.id.search_recyclerview);
        mRecyclerView.setHasFixedSize(true);
        LinearLayoutManager manager = new LinearLayoutManager(Search.this,LinearLayoutManager.VERTICAL,false);
        mRecyclerView.setLayoutManager(manager);

        firestoreVeriKaynagi = new FirestoreVeriKaynagi();

        firestoreVeriKaynagi.kullaniciBilgileriniGetir(kullaniciList -> {
            adapter = new FirestoreRecyclerViewAdapter(kullaniciList);
            mRecyclerView.setAdapter(adapter);
        });
    }
}